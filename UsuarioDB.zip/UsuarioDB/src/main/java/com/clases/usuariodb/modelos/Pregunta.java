/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.clases.usuariodb.modelos;

/**
 *
 * @author magb
 */
public class Pregunta {
    private int numero;
    private String pregunta;
    private String ruta;
    private boolean op1;
    private boolean op2;
    private boolean op3;

    public Pregunta(int numero, String pregunta, String ruta, boolean op1, boolean op2, boolean op3) {
        this.numero = numero;
        this.pregunta = pregunta;
        this.ruta = ruta;
        this.op1 = op1;
        this.op2 = op2;
        this.op3 = op3;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getPregunta() {
        return pregunta;
    }

    public void setPregunta(String pregunta) {
        this.pregunta = pregunta;
    }

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    public boolean isOp1() {
        return op1;
    }

    public void setOp1(boolean op1) {
        this.op1 = op1;
    }

    public boolean isOp2() {
        return op2;
    }

    public void setOp2(boolean op2) {
        this.op2 = op2;
    }

    public boolean isOp3() {
        return op3;
    }

    public void setOp3(boolean op3) {
        this.op3 = op3;
    }
        
      
    
}
